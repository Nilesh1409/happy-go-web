"use client";
import Link from "next/link";
import Image from "next/image";
import {
  Calendar,
  Star,
  Bike,
  Building2,
  Gift,
  User,
  Phone,
  Award,
  Users,
  StarIcon,
  ChevronLeft,
  ChevronRight,
  Mail,
  MapPin,
} from "lucide-react";

export default function Footer() {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent(
      "Hi! I need help with bike booking. Can you assist me?"
    );
    const whatsappUrl = `https://wa.me/919008022800?text=${message}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {/* Company Info */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                <Image
                  src="/assets/happygo.jpeg"
                  alt="HappyGo Logo"
                  width={48}
                  height={48}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold">HappyGo</h3>
                <p className="text-xs sm:text-sm text-gray-400">
                  Anywhere Everytime
                </p>
              </div>
            </div>
            <p className="text-gray-400 mb-4 text-sm sm:text-base max-w-md">
              The reliable travel company operating in Chikkamagaluru since 2010
              and Happy Go Bike Rental is the subsidiary company of Happy Go
              Group. Happy Ride Happy Stay!
            </p>

            {/* Contact Actions */}
            <div className="flex flex-wrap gap-3">
              <a
                href="tel:+919008022800"
                className="flex items-center space-x-2 text-gray-400 hover:text-[#F47B20] transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span className="text-sm">Call</span>
              </a>
              <a
                href="mailto:happygobikerentals@gmail.com"
                className="flex items-center space-x-2 text-gray-400 hover:text-[#F47B20] transition-colors"
              >
                <Mail className="w-4 h-4" />
                <span className="text-sm">Email</span>
              </a>
              <button
                onClick={handleWhatsAppClick}
                className="flex items-center space-x-2 text-gray-400 hover:text-green-500 transition-colors"
              >
                <svg
                  className="w-4 h-4"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.106" />
                </svg>
                <span className="text-sm">Chat with us</span>
              </button>
            </div>
          </div>

          {/* Our Location */}
          <div className="sm:col-span-1">
            <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">
              Our Location
            </h4>
            <div className="space-y-2 text-gray-400">
              <div className="flex items-start">
                <MapPin className="w-4 h-4 mr-2 mt-1 flex-shrink-0" />
                <div className="text-sm">
                  <p>MG ROAD, SURYA SWEETS BUILDING,</p>
                  <p>CHIKKAMAGALURU 577101</p>
                </div>
              </div>
            </div>
          </div>

          {/* Get In Touch */}
          <div className="sm:col-span-1">
            <h4 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">
              Get In Touch
            </h4>
            <div className="space-y-3 text-gray-400">
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="text-sm">CHIKKAMAGALURU 577101</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                <a
                  href="mailto:happygobikerentals@gmail.com"
                  className="text-sm hover:text-[#F47B20] transition-colors break-all"
                >
                  happygobikerentals@gmail.com
                </a>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                <a
                  href="tel:+919008022800"
                  className="text-sm hover:text-[#F47B20] transition-colors"
                >
                  +91 90080-22800
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="border-t border-gray-800 mt-6 sm:mt-8 pt-6 sm:pt-8">
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <h5 className="font-semibold mb-3 text-sm sm:text-base">
                About Happygorentals
              </h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link
                    href="/about"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/privacy"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link
                    href="/cancellation"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Cancellation & Refund Policy
                  </Link>
                </li>
                <li>
                  <Link
                    href="/terms"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Terms & Condition
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-3 text-sm sm:text-base">
                Services
              </h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link
                    href="/"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Bike Rental
                  </Link>
                </li>
                <li>
                  <Link
                    href="/products"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Products
                  </Link>
                </li>
                <li>
                  <Link
                    href="/hostels"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Hostels
                  </Link>
                </li>
                <li>
                  <Link
                    href="/refer-earn"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Refer & Earn
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-3 text-sm sm:text-base">
                Popular Bikes
              </h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link
                    href="/search?brand=honda"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Honda Bikes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/search?brand=yamaha"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Yamaha Bikes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/search?brand=royal-enfield"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Royal Enfield
                  </Link>
                </li>
                <li>
                  <Link
                    href="/search?brand=ktm"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    KTM Bikes
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-3 text-sm sm:text-base">
                Support
              </h5>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link
                    href="/contact"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/faq"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link
                    href="/help"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    Help Center
                  </Link>
                </li>
                <li>
                  <a
                    href="tel:+919008022800"
                    className="hover:text-[#F47B20] transition-colors"
                  >
                    24/7 Support
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 pt-4 sm:pt-6 text-center text-xs sm:text-sm text-gray-400">
          <p>
            © 2024 <span className="text-[#F47B20]">Happy Go Bike Rentals</span>{" "}
            - All rights reserved.
          </p>
          <p className="mt-1">
            Best Bike Rental Service in Chikkamagaluru | Happy Ride Happy Stay
          </p>
        </div>
      </div>

      {/* Bottom Navigation for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t md:hidden z-40">
        <div className="grid grid-cols-5 py-2">
          <Link
            href="/"
            className="flex flex-col items-center py-2 text-[#F47B20]"
          >
            <Bike className="w-5 h-5" />
            <span className="text-xs mt-1">Bike</span>
          </Link>
          <Link
            href="/bookings"
            className="flex flex-col items-center py-2 text-gray-600"
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs mt-1">Bookings</span>
          </Link>
          <Link
            href="/products"
            className="flex flex-col items-center py-2 text-gray-600"
          >
            <Building2 className="w-5 h-5" />
            <span className="text-xs mt-1">Products</span>
          </Link>
          <Link
            href="/refer-earn"
            className="flex flex-col items-center py-2 text-gray-600"
          >
            <Gift className="w-5 h-5" />
            <span className="text-xs mt-1">Refer&Earn</span>
          </Link>
          <Link
            href="/profile"
            className="flex flex-col items-center py-2 text-gray-600"
          >
            <User className="w-5 h-5" />
            <span className="text-xs mt-1">Profile</span>
          </Link>
        </div>
      </div>
    </footer>
  );
}
